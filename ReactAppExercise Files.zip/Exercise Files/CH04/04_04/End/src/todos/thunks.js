export const displayAlert = text => () => {
    alert(`You clicked on: ${text}`);
};